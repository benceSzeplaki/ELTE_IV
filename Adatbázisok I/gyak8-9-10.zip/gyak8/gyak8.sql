CREATE OR REPLACE FUNCTION MY_IS_PRIME(n IN DOLGOZO.DKOD%TYPE) RETURN NUMBER IS
BEGIN
    DECLARE
        i NUMBER;
        is_prime NUMBER;
    BEGIN
        i := 2;
        is_prime := 1;
        FOR i IN 2..n/2 LOOP
            IF mod(n, i) = 0 THEN
                is_prime := 0;
                EXIT;
            END IF;
        END LOOP;
        IF is_prime = 1 THEN
            RETURN 1; -- true
        ELSE
            RETURN 0; -- false
        END IF;
    END;
END;

CREATE TABLE GYAK8 AS SELECT DKOD, DNEV FROM DOLGOZO WHERE MY_IS_PRIME(DKOD) = 1;